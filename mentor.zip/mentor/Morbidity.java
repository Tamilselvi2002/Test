package mentor;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;



public class Morbidity extends SignIn {
	
   
 
  
   // @Test
    public void Morbi( WebDriver driver) throws InterruptedException {
    	
    	
      // WebDriver driver=SignIn.driver; 
    Thread.sleep(2000);
    Actions builder=new Actions(driver);
	WebElement element = driver.findElement(By.xpath("(//div[text()='Morbidity'])[2]"));
	builder.moveToElement(element).click().build().perform();
	String text=element.getText();
	System.out.println(text);
	Thread.sleep(2000);
	
	
	// to click the view button
	String name="Ribha";
	driver.findElement(By.xpath("//div[text()='"+name+"']/following::div/div")).click();
	
	
	//to click visit2 and download the report
	/*driver.findElement(By.xpath("//a[text()='Visit 2']")).click();
	driver.findElement(By.xpath("(//span[contains(text(),'Download Report')])[4]")).click();
	Thread.sleep(2000);
	System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());*/
	
	
	
	//get the url of the page
	  String currentUrl = driver.getCurrentUrl();
	  System.out.println(currentUrl);
	  String url="https://community.medyaan.com/morbidities";
	  
	  if(currentUrl.equals(url)) {
		  System.out.println("the url is verified");
	  }
	  //using Assert 
	  Assert.assertEquals(url, currentUrl);
	  
	  
	//click visit dropdown
	WebElement element3 = driver.findElement(By.xpath("(//div[text()='Morbidity'])[2]"));
	builder.moveToElement(element3).click().build().perform();
	Thread.sleep(2000);
	
	
	
        // to get the total member name
	
		List<WebElement> mem = driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
		for (WebElement member : mem) {
			System.out.println(member.getText());
		}
		
		
		
   //	driver.findElement(By.xpath("//button[text()='Visit No']")).click();
	//driver.findElement(By.xpath("(//label[text()='2'])[2]")).click();
	//driver.findElement(By.xpath("(//label[text()='3'])[2]")).click();*/
	
		
		
  /*//click Morbility
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[text()='Morbidity']")).click();
	driver.findElement(By.xpath("//label[text()='Abdominal hernia']")).click();
	List<WebElement> list2 = driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
	for (WebElement web2 : list2) {
		System.out.println(web2.getText());*/
		
		
		// click the download button
		driver.findElement(By.xpath("//button[@data-test='download-button']")).click();
		
		
		//search 
		/*WebElement search = driver.findElement(By.cssSelector("#hodfamilyquickFilter"));
		search.clear();
		search.sendKeys("Jack");
		System.out.println(driver.findElement(By.xpath("//div[@class='custom-cell-icon-container']")).getText());*/
		
		
		
	// Area filter
		/*driver.findElement(By.xpath("//button[text()='Area']")).click();
		String place="AVR";
		driver.findElement(By.xpath("//ul[@aria-labelledby='__BVID__330__BV_toggle_']/div/label[text()='"+place+"']")).click();
	   List<WebElement> pl = driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
		for (WebElement web : pl) {
			System.out.println(web.getText());
		}*/
		
		
		
     //Proficiency filter
		/*driver.findElement(By.xpath("//button[text()='Proficiency']")).click();
		String prof="2";
		driver.findElement(By.xpath("//ul[@aria-labelledby='__BVID__338__BV_toggle_']/div/label[text()='"+prof+"']")).click();
		List<WebElement> li= driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
	for (WebElement web1 : li) {
		System.out.println(web1.getText());
	}*/
	
		
		
		// Morbidity filter
	/*	driver.findElement(By.xpath("//button[text()='Morbidity']")).click();
		String mobidity="Acute pancreatitis";
		driver.findElement(By.xpath("//ul[@aria-labelledby='__BVID__339__BV_toggle_']/div/label[text()='"+mobidity+"']")).click();
	    List<WebElement> li2 = driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
	     for (WebElement web2 : li2) {
	    	 System.out.println(web2.getText());
		}*/
	     
	     
	     
		//visit filter
		driver.findElement(By.xpath("//button[text()='Visit No']")).click();
		String num="4";
		driver.findElement(By.xpath("//ul[@aria-labelledby='__BVID__340__BV_toggle_']/div/label[text()='"+num+"']")).click();
	    List<WebElement> li3 = driver.findElements(By.xpath("//div[@class='custom-cell-icon-container']"));
	    for (WebElement web3 : li3) {
	    	 System.out.println(web3.getText());	
		}
		
		
		
		//List<WebElement> visit = driver.findElements(By.xpath("//ul[@aria-labelledby='__BVID__340__BV_toggle_']/div"));
		/*for (WebElement web1 : visit) {
			System.out.println( web1.getText());
			
			if(web1.getText().contains("3")) {
				web1.click();
				}	
		}*/
		
	
	
	  // to edit the visit of roopa
	/*driver.findElement(By.xpath("//button[@class='btn edit-btn btn-secondary']")).click();
	driver.findElement(By.xpath("//ul[@class='nav nav-tabs']/li[2]")).click();
	WebElement drop = driver.findElement(By.xpath("//select[@class='custom-select profile-input']"));
	Select down=new Select(drop);
	down.selectByIndex(2);
	driver.findElement(By.xpath("//input[@name='datepicker']")).click();
	driver.findElement(By.xpath("//td[@class='available']/div/span[1]")).click();
	driver.findElement(By.xpath("(//div[@class='multiselect__tags'])[1]")).click();
	driver.findElement(By.xpath("//span[text()='Non Vegetarian']")).click();
	driver.findElement(By.xpath("(//input[@class='form-control profile-input'])[1]")).sendKeys("farmer");
	driver.findElement(By.xpath("(//div[@class='multiselect__tags'])[2]")).click();
	driver.findElement(By.xpath("//span[text()='Exercise']")).click();

	}*/
	}
    
    public static void main(String[] args) throws InterruptedException {
		Morbidity mob=new Morbidity();
		mob.signin();
		mob.Morbi(driver);
		
	}
  }
	
	
	
	
	



