package mentor;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.xmlbeans.impl.soap.Text;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class Student {
public static void main(String[] args) throws InterruptedException, AWTException {
	
	
	//Launch browser
	WebDriver driver=new ChromeDriver();
	driver.get("https://community.medyaan.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
	
	//Sign in
	driver.findElement(By.xpath("//input[@name='phone']")).sendKeys("9952346094");
	driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Admin@123");
	driver.findElement(By.xpath("//div[@class='login-button-box']")).click();
	
	
	//click student module
	Actions builder=new Actions(driver);
	WebElement ele = driver.findElement(By.xpath("(//div[text()='Student'])[2]"));
	builder.moveToElement(ele).click().build().perform();
	Thread.sleep(2000);
	
	
	//To add Student and Submit it 
/*	driver.findElement(By.xpath("//button[@data-test='add-family-button']")).click();
	driver.findElement(By.cssSelector("#__BVID__183")).sendKeys("logith");
	driver.findElement(By.cssSelector("#__BVID__184")).sendKeys("Arul");
	driver.findElement(By.cssSelector("#__BVID__185")).sendKeys("200230");
	driver.findElement(By.cssSelector("#__BVID__186")).sendKeys("300002");
	WebElement down = driver.findElement(By.xpath("(//select[@class='custom-select'])[1]"));
	Select drop=new Select(down);
	drop.selectByIndex(2);
	driver.findElement(By.xpath("//span[text()='Female']")).click();
	driver.findElement(By.cssSelector("#__BVID__193")).sendKeys("814800122");
	driver.findElement(By.cssSelector("#__BVID__194")).sendKeys("dha@gmail.com");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());*/
	
	
	
	// to 
	/*driver.findElement(By.xpath("//button[@data-test='add-family-button']")).click();
	driver.findElement(By.cssSelector("#__BVID__183")).sendKeys("dharani");
	driver.findElement(By.cssSelector("#__BVID__184")).sendKeys("Dharani");
	driver.findElement(By.cssSelector("#__BVID__185")).sendKeys("200230");
	driver.findElement(By.cssSelector("#__BVID__186")).sendKeys("300002");
	WebElement down = driver.findElement(By.xpath("(//select[@class='custom-select'])[1]"));
	Select drop=new Select(down);
	drop.selectByIndex(2);
	driver.findElement(By.xpath("//span[text()='Female']")).click();
	driver.findElement(By.cssSelector("#__BVID__193")).sendKeys("81480000001");
	driver.findElement(By.cssSelector("#__BVID__194")).sendKeys("dharani123@gmail.com");
	Thread.sleep(2000);
	driver.findElement(By.xpath("(//button[@class='btn back-nav-btn btn-secondary'])[1]")).click();
	driver.findElement(By.xpath("//button[@class='el-button el-button--default el-button--small el-button--primary ']")).click();*/

	//to edit the added details and save it
/*	driver.findElement(By.xpath("(//button[@title='Edit Details'])[1]")).click();
	Thread.sleep(2000);
	WebElement element = driver.findElement(By.xpath("(//input[@class='form-control'])[2]"));
	element.clear();
	element.sendKeys("A");
	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());*/
	
	
	// to edit the added details and  cancel it
   /* List<WebElement> list = driver.findElements(By.xpath("//div[@class='ag-center-cols-container']/div"));
    for (WebElement webElement : list) {
		String text = webElement.getText();
		System.out.println(text);
		Thread.sleep(2000);
		if(text.contains("abc@gamil.com"))
		{
		 driver.findElement(By.xpath("//div[@class='ag-row-odd ag-row-no-focus ag-row ag-row-level-0 ag-row-position-absolute']/div[@col-id='action']")).click();
  }
 }*/
	/*
	 * String mail="tharun@gmail.com";
	 * driver.findElement(By.xpath("//div[contains(text(),'"+mail+
	 * "')]/following::div/div")).click(); driver.findElement(By.
	 * xpath("(//button[@class='btn back-nav-btn btn-secondary'])[1]")).click();
	 * driver.findElement(By.
	 * xpath("//button[@class='el-button el-button--default el-button--small el-button--primary ']"
	 * )).click();
	 * driver.findElement(By.xpath("//input[@id='ag-180-input']")).click();
	 * 
	 */
    // to edit the details and cancel it
	/*driver.findElement(By.xpath("(//button[@title='Edit Details'])")).click();
	Thread.sleep(2000);
	WebElement element = driver.findElement(By.xpath("(//input[@class='form-control'])[1]"));
	element.clear();
	element.sendKeys("selvi");
	driver.findElement(By.xpath("(//button[@class='btn back-nav-btn btn-secondary'])[1]")).click();
	driver.findElement(By.xpath("//button[@class='el-button el-button--default el-button--small el-button--primary ']/span")).click();*/
	
	
	// To achieve the student
	/*driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[1]")).click();
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[2]")).click();
	driver.findElement(By.xpath("//button[@id='dropdown-1__BV_toggle_']")).click();
	driver.findElement(By.xpath("(//a[@class='dropdown-item text-primary'])[3]")).click();
	Thread.sleep(2000);
	System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());*/
	
	
	//Archieve
	String archive="7094755145";
	WebElement arc1 = driver.findElement(By.xpath("//div[text()='"+archive+"']"));
	System.out.println(arc1.getText());
	arc1.click();
	driver.findElement(By.xpath("//button[@id='dropdown-1__BV_toggle_']")).click();
	driver.findElement(By.xpath("(//a[@class='dropdown-item text-primary'])[3]")).click();
	Thread.sleep(2000);
    System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());
	
	
	
	//to click Archieve
    Thread.sleep(2000);
	WebElement icon = driver.findElement(By.xpath("//i[@class='v-icon notranslate custom-icon mdi mdi-archive theme--light']"));
	builder.moveToElement(icon).click().build().perform();
	Thread.sleep(2000);
	
	//WebElement arc2 = driver.findElement(By.xpath("//div[text()='"+archive+"']"));
	//System.out.println(arc2.getText());
//	Assert.assertEquals(arc1, arc2);
	
	List<WebElement> num = driver.findElements(By.xpath("//div[@class='ag-center-cols-container']/div/div[@col-id='mobileno']"));

	for(int i=0; i<num.size();i++) {
		String el=num.get(i).getText();
		if(archive.equals(el)) {
			System.out.println("num is archieved"+ el);
			break;
		}else {
			System.out.println("num not found");
		}
	
	}
	
	// Update Profiviency and Update it
	/*Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[2]")).click();
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[3]")).click();
	driver.findElement(By.xpath("//button[@id='dropdown-1__BV_toggle_']")).click();
	driver.findElement(By.xpath("(//a[@class='dropdown-item text-primary'])[1]")).click();
	driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[2]")).click();
	Thread.sleep(2000);
	System.out.println(driver.findElement(By.xpath("//p[@class='el-message__content']")).getText());*/

	
	// Update proficiency and cancel it
	/*Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[3]")).click();
	driver.findElement(By.xpath("//button[@id='dropdown-1__BV_toggle_']")).click();
	driver.findElement(By.xpath("(//a[@class='dropdown-item text-primary'])[1]")).click();
	driver.findElement(By.xpath("(//button[@class='btn back-nav-btn btn-secondary'])[3]")).click();
	driver.findElement(By.xpath("//button[@class='el-button el-button--default el-button--small el-button--primary ']")).click();*/
	
	
	
	//Upload the student file
	/*Thread.sleep(2000);
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[3]")).click();
	driver.findElement(By.xpath("(//div[@ref='eCheckbox'])[4]")).click();
	driver.findElement(By.xpath("//button[@id='dropdown-1__BV_toggle_']")).click();
	driver.findElement(By.xpath("(//a[@class='dropdown-item text-primary'])[2]")).click();
	driver.findElement(By.xpath("//label[@class='custom-file-label']")).click();
	Thread.sleep(2000);
	Robot rob=new Robot();
	    StringSelection file=new StringSelection("\"C:\\Users\\tamil\\Downloads\\LION framework - April Week 04.xlsx\"");
	   Toolkit.getDefaultToolkit().getSystemClipboard().setContents(file, null);  
	    rob.keyPress(KeyEvent.VK_CONTROL);
	    rob.keyPress(KeyEvent.VK_V);
	    rob.keyRelease(KeyEvent.VK_CONTROL);
	    rob.keyRelease(KeyEvent.VK_V);
	    Thread.sleep(2000);
	    rob.keyPress(KeyEvent.VK_ENTER);
	    rob.keyRelease(KeyEvent.VK_ENTER);
     driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[2]")).click();
	 System.out.println(driver.findElement(By.xpath("(//p[@class='el-message__content'])[1]")).getText());
	 System.out.println(driver.findElement(By.xpath("(//p[@class='el-message__content'])[2]")).getText());*/

	    
 // proficieny filter
  /*Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@class='btn dropdown-toggle btn-primary']")).click();
	driver.findElement(By.xpath("(//label[@class='custom-control-label'])[2]")).click();
	List<WebElement> pro2 = driver.findElements(By.xpath("//div[@class='ag-cell-wrapper']"));
	for (WebElement web1 : pro2) {
    System.out.println(web1.getText());}*/
	
	
	//search
	/*WebElement search = driver.findElement(By.cssSelector("#hodquickFilter"));
	search.sendKeys("Aparna");
	System.out.println(driver.findElement(By.xpath("//span[@class='ag-cell-value']")).getText());*/
	
}
}
